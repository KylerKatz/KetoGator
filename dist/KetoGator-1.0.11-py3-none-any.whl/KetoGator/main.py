from qt5 import *

def main():
    app = QApplication(sys.argv)
    
    # login = Login()
    # login.show()
    
    # window = MainUI()
    # window.show()
    test = Test()
    test.show()
    app.exec_()


if __name__ == "__main__":
    main()