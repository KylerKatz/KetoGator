# KetoGator

## Current dependencies 
### PyQt5: 
pip install PyQt5
### Pandas:
pip install pandas
### Excel for Pandas:
pip install xlrd
